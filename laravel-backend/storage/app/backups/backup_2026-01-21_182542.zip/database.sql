mysqldump: [Warning] Using a password on the command line interface can be insecure.
-- MySQL dump 10.13  Distrib 8.0.40, for macos12.7 (arm64)
--
-- Host: 127.0.0.1    Database: academic_nexus_portal
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `academic_calendars`
--

DROP TABLE IF EXISTS `academic_calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `academic_calendars` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` enum('semester_start','semester_end','exam_period','registration_period','holiday','break','orientation','graduation','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `semester` int DEFAULT NULL,
  `academic_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_holiday` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('scheduled','ongoing','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'scheduled',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `academic_calendars_academic_year_semester_index` (`academic_year`,`semester`),
  KEY `academic_calendars_start_date_end_date_index` (`start_date`,`end_date`),
  KEY `academic_calendars_event_type_index` (`event_type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `academic_calendars`
--

LOCK TABLES `academic_calendars` WRITE;
/*!40000 ALTER TABLE `academic_calendars` DISABLE KEYS */;
INSERT INTO `academic_calendars` VALUES (1,'Fall Semester Begins','semester_start','2026-01-15','2026-01-15',1,'2026','First day of Fall semester classes',0,'ongoing','2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,'Course Registration - Spring 2026','registration_period','2026-02-01','2026-02-15',2,'2026','Registration period for Spring semester courses',0,'scheduled','2026-01-18 14:19:58','2026-01-18 14:19:58'),(3,'Mid-Term Examinations','exam_period','2026-03-10','2026-03-20',1,'2026','Mid-term exams for all courses',0,'scheduled','2026-01-18 14:19:58','2026-01-18 14:19:58'),(4,'Spring Break','break','2026-04-05','2026-04-12',NULL,'2026','University closed for spring break',1,'scheduled','2026-01-18 14:19:58','2026-01-18 14:19:58'),(5,'Final Examinations - Fall Semester','exam_period','2026-05-15','2026-05-30',1,'2026','Final exams for Fall semester',0,'scheduled','2026-01-18 14:19:58','2026-01-18 14:19:58'),(6,'Independence Day','holiday','2026-07-04','2026-07-04',NULL,'2026','National holiday - University closed',1,'scheduled','2026-01-18 14:19:58','2026-01-18 14:19:58'),(7,'Assignment Submission Deadline','other','2026-05-10','2026-05-10',1,'2026','Final deadline for all pending assignments',0,'scheduled','2026-01-18 14:19:58','2026-01-18 14:19:58'),(8,'New Student Orientation','orientation','2026-08-25','2026-08-27',1,'2026','Orientation program for incoming students',0,'scheduled','2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `academic_calendars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accommodation_amenities`
--

DROP TABLE IF EXISTS `accommodation_amenities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accommodation_amenities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hostel_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amenity_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT '1',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accommodation_amenities_hostel_name_index` (`hostel_name`),
  KEY `accommodation_amenities_is_available_index` (`is_available`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accommodation_amenities`
--

LOCK TABLES `accommodation_amenities` WRITE;
/*!40000 ALTER TABLE `accommodation_amenities` DISABLE KEYS */;
/*!40000 ALTER TABLE `accommodation_amenities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accommodation_fees`
--

DROP TABLE IF EXISTS `accommodation_fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accommodation_fees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `accommodation_id` bigint unsigned NOT NULL,
  `fee_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` enum('pending','partial','paid','waived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `due_date` date DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `receipt_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accommodation_fees_accommodation_id_index` (`accommodation_id`),
  KEY `accommodation_fees_status_index` (`status`),
  CONSTRAINT `accommodation_fees_accommodation_id_foreign` FOREIGN KEY (`accommodation_id`) REFERENCES `student_accommodations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accommodation_fees`
--

LOCK TABLES `accommodation_fees` WRITE;
/*!40000 ALTER TABLE `accommodation_fees` DISABLE KEYS */;
/*!40000 ALTER TABLE `accommodation_fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accommodation_roommates`
--

DROP TABLE IF EXISTS `accommodation_roommates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accommodation_roommates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `accommodation_id` bigint unsigned NOT NULL,
  `roommate_student_id` bigint unsigned NOT NULL,
  `roommate_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roommate_matric_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roommate_department` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roommate_level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roommate_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roommate_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accommodation_roommates_accommodation_id_index` (`accommodation_id`),
  KEY `accommodation_roommates_roommate_student_id_index` (`roommate_student_id`),
  CONSTRAINT `accommodation_roommates_accommodation_id_foreign` FOREIGN KEY (`accommodation_id`) REFERENCES `student_accommodations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `accommodation_roommates_roommate_student_id_foreign` FOREIGN KEY (`roommate_student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accommodation_roommates`
--

LOCK TABLES `accommodation_roommates` WRITE;
/*!40000 ALTER TABLE `accommodation_roommates` DISABLE KEYS */;
/*!40000 ALTER TABLE `accommodation_roommates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('general','academic','event','urgent','holiday') COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` enum('low','medium','high','critical') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `target_audience` json NOT NULL,
  `department_id` bigint unsigned DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `attachments` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `announcements_department_id_foreign` (`department_id`),
  KEY `announcements_created_by_foreign` (`created_by`),
  CONSTRAINT `announcements_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `announcements_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment_grades`
--

DROP TABLE IF EXISTS `assignment_grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignment_grades` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `assignment_id` bigint unsigned NOT NULL,
  `score` decimal(5,2) NOT NULL,
  `feedback` text COLLATE utf8mb4_unicode_ci,
  `graded_by` bigint unsigned NOT NULL,
  `graded_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `assignment_grades_student_id_assignment_id_unique` (`student_id`,`assignment_id`),
  KEY `assignment_grades_assignment_id_foreign` (`assignment_id`),
  KEY `assignment_grades_graded_by_foreign` (`graded_by`),
  CONSTRAINT `assignment_grades_assignment_id_foreign` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assignment_grades_graded_by_foreign` FOREIGN KEY (`graded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assignment_grades_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_grades`
--

LOCK TABLES `assignment_grades` WRITE;
/*!40000 ALTER TABLE `assignment_grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `assignment_grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment_submissions`
--

DROP TABLE IF EXISTS `assignment_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignment_submissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `assignment_id` bigint unsigned NOT NULL,
  `student_id` bigint unsigned NOT NULL,
  `submission_text` text COLLATE utf8mb4_unicode_ci,
  `file_paths` json DEFAULT NULL,
  `file_metadata` json DEFAULT NULL,
  `submitted_at` timestamp NOT NULL,
  `status` enum('submitted','late','graded','returned') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'submitted',
  `grade` decimal(5,2) DEFAULT NULL,
  `teacher_feedback` text COLLATE utf8mb4_unicode_ci,
  `graded_at` timestamp NULL DEFAULT NULL,
  `graded_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `assignment_submissions_assignment_id_student_id_unique` (`assignment_id`,`student_id`),
  KEY `assignment_submissions_student_id_foreign` (`student_id`),
  KEY `assignment_submissions_graded_by_foreign` (`graded_by`),
  KEY `assignment_submissions_assignment_id_student_id_index` (`assignment_id`,`student_id`),
  KEY `assignment_submissions_submitted_at_index` (`submitted_at`),
  KEY `assignment_submissions_status_index` (`status`),
  CONSTRAINT `assignment_submissions_assignment_id_foreign` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assignment_submissions_graded_by_foreign` FOREIGN KEY (`graded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `assignment_submissions_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_submissions`
--

LOCK TABLES `assignment_submissions` WRITE;
/*!40000 ALTER TABLE `assignment_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assignment_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignments`
--

DROP TABLE IF EXISTS `assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assignments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `due_date` datetime NOT NULL,
  `max_score` int NOT NULL,
  `status` enum('draft','published','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assignments_course_id_status_index` (`course_id`,`status`),
  KEY `assignments_due_date_index` (`due_date`),
  CONSTRAINT `assignments_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignments`
--

LOCK TABLES `assignments` WRITE;
/*!40000 ALTER TABLE `assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendances`
--

DROP TABLE IF EXISTS `attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `course_id` bigint unsigned NOT NULL,
  `teacher_id` bigint unsigned NOT NULL,
  `date` date NOT NULL,
  `status` enum('present','absent','late','excused') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'absent',
  `marked_at` timestamp NULL DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attendances_student_id_course_id_date_unique` (`student_id`,`course_id`,`date`),
  KEY `attendances_course_id_foreign` (`course_id`),
  KEY `attendances_teacher_id_foreign` (`teacher_id`),
  CONSTRAINT `attendances_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `attendances_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  CONSTRAINT `attendances_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendances`
--

LOCK TABLES `attendances` WRITE;
/*!40000 ALTER TABLE `attendances` DISABLE KEYS */;
/*!40000 ALTER TABLE `attendances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_data` json DEFAULT NULL,
  `status_code` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_index` (`user_id`),
  KEY `audit_logs_action_index` (`action`),
  KEY `audit_logs_created_at_index` (`created_at`),
  KEY `audit_logs_ip_address_index` (`ip_address`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `continuous_assessments`
--

DROP TABLE IF EXISTS `continuous_assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `continuous_assessments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `course_id` bigint unsigned NOT NULL,
  `semester_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assessment_type` enum('quiz','assignment','midterm','project') COLLATE utf8mb4_unicode_ci NOT NULL,
  `assessment_number` int NOT NULL DEFAULT '1',
  `score` decimal(5,2) NOT NULL,
  `max_score` decimal(5,2) NOT NULL DEFAULT '10.00',
  `weight` decimal(5,2) NOT NULL DEFAULT '5.00',
  `weighted_score` decimal(5,2) DEFAULT NULL,
  `assessment_date` date DEFAULT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `locked_at` timestamp NULL DEFAULT NULL,
  `locked_by` bigint unsigned DEFAULT NULL,
  `submitted_for_approval_at` timestamp NULL DEFAULT NULL,
  `approval_status` enum('draft','submitted','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `approved_by` bigint unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `continuous_assessments_course_id_foreign` (`course_id`),
  KEY `continuous_assessments_student_id_course_id_semester_code_index` (`student_id`,`course_id`,`semester_code`),
  KEY `continuous_assessments_assessment_type_index` (`assessment_type`),
  KEY `continuous_assessments_locked_by_foreign` (`locked_by`),
  KEY `continuous_assessments_approved_by_foreign` (`approved_by`),
  KEY `continuous_assessments_approval_status_index` (`approval_status`),
  CONSTRAINT `continuous_assessments_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `continuous_assessments_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `continuous_assessments_locked_by_foreign` FOREIGN KEY (`locked_by`) REFERENCES `users` (`id`),
  CONSTRAINT `continuous_assessments_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `continuous_assessments`
--

LOCK TABLES `continuous_assessments` WRITE;
/*!40000 ALTER TABLE `continuous_assessments` DISABLE KEYS */;
/*!40000 ALTER TABLE `continuous_assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_prerequisites`
--

DROP TABLE IF EXISTS `course_prerequisites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_prerequisites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned NOT NULL,
  `prerequisite_course_id` bigint unsigned NOT NULL,
  `minimum_grade` decimal(3,2) DEFAULT NULL,
  `requirement_type` enum('required','recommended','corequisite') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'required',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `course_prerequisites_course_id_prerequisite_course_id_unique` (`course_id`,`prerequisite_course_id`),
  KEY `course_prerequisites_prerequisite_course_id_foreign` (`prerequisite_course_id`),
  KEY `course_prerequisites_course_id_index` (`course_id`),
  CONSTRAINT `course_prerequisites_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `course_prerequisites_prerequisite_course_id_foreign` FOREIGN KEY (`prerequisite_course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_prerequisites`
--

LOCK TABLES `course_prerequisites` WRITE;
/*!40000 ALTER TABLE `course_prerequisites` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_prerequisites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_waitlists`
--

DROP TABLE IF EXISTS `course_waitlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_waitlists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned NOT NULL,
  `student_id` bigint unsigned NOT NULL,
  `position` int NOT NULL,
  `semester` int NOT NULL,
  `academic_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('waiting','enrolled','removed','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'waiting',
  `added_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enrolled_at` timestamp NULL DEFAULT NULL,
  `removed_at` timestamp NULL DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `waitlist_unique` (`course_id`,`student_id`,`semester`,`academic_year`),
  KEY `course_waitlists_student_id_foreign` (`student_id`),
  KEY `course_waitlists_course_id_status_position_index` (`course_id`,`status`,`position`),
  CONSTRAINT `course_waitlists_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `course_waitlists_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_waitlists`
--

LOCK TABLES `course_waitlists` WRITE;
/*!40000 ALTER TABLE `course_waitlists` DISABLE KEYS */;
INSERT INTO `course_waitlists` VALUES (1,1,1,1,1,'2025-2026','waiting','2026-01-12 14:19:58',NULL,NULL,NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,1,2,2,1,'2025-2026','waiting','2026-01-15 14:19:58',NULL,NULL,NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `course_waitlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `credits` int NOT NULL,
  `grade_components` json DEFAULT NULL,
  `has_curve` tinyint(1) NOT NULL DEFAULT '0',
  `curve_percentage` decimal(5,2) DEFAULT NULL,
  `max_capacity` int NOT NULL DEFAULT '50',
  `min_capacity` int NOT NULL DEFAULT '10',
  `department_id` bigint unsigned NOT NULL,
  `teacher_id` bigint unsigned DEFAULT NULL,
  `semester` int NOT NULL,
  `section` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule` json DEFAULT NULL,
  `room` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `max_students` int NOT NULL DEFAULT '50',
  `enrolled_students` int NOT NULL DEFAULT '0',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('active','inactive','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `courses_code_unique` (`code`),
  KEY `courses_department_id_foreign` (`department_id`),
  KEY `courses_teacher_id_foreign` (`teacher_id`),
  CONSTRAINT `courses_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `courses_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'Data Structures and Algorithms','CS301','Fundamental data structures and algorithms',3,NULL,0,NULL,50,10,1,1,3,'A','[{\"day\": \"Monday\", \"time\": \"09:00-10:30\"}, {\"day\": \"Wednesday\", \"time\": \"09:00-10:30\"}, {\"day\": \"Friday\", \"time\": \"09:00-10:30\"}]','Room 301',50,1,'2024-01-15','2024-05-15','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,'Marketing Management','BA201','Principles and practices of marketing management',3,NULL,0,NULL,50,10,2,2,2,'B','[{\"day\": \"Tuesday\", \"time\": \"11:00-12:30\"}, {\"day\": \"Thursday\", \"time\": \"11:00-12:30\"}]','Room 205',45,1,'2024-01-15','2024-05-15','active','2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `degree_programs`
--

DROP TABLE IF EXISTS `degree_programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `degree_programs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `department_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `degree_type` enum('associate','bachelor','master','doctorate','certificate','diploma') COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_credits_required` int NOT NULL,
  `duration_years` int NOT NULL,
  `duration_semesters` int NOT NULL,
  `minimum_cgpa` decimal(3,2) NOT NULL DEFAULT '2.00',
  `description` text COLLATE utf8mb4_unicode_ci,
  `program_objectives` json DEFAULT NULL,
  `status` enum('active','inactive','archived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `degree_programs_code_unique` (`code`),
  KEY `degree_programs_department_id_index` (`department_id`),
  KEY `degree_programs_status_index` (`status`),
  CONSTRAINT `degree_programs_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `degree_programs`
--

LOCK TABLES `degree_programs` WRITE;
/*!40000 ALTER TABLE `degree_programs` DISABLE KEYS */;
INSERT INTO `degree_programs` VALUES (1,1,'Bachelor of Science in Computer Science','BSCS','bachelor',120,4,8,2.00,'A comprehensive program covering software development, algorithms, systems programming, and computer theory.',NULL,'active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,1,'Bachelor of Science in Information Technology','BSIT','bachelor',120,4,8,2.00,'Focuses on practical IT skills including networking, database administration, and web development.',NULL,'active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(3,1,'Bachelor of Science in Mathematics','BSMATH','bachelor',120,4,8,2.00,'Advanced study of pure and applied mathematics including calculus, algebra, and statistics.',NULL,'active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(4,1,'Master of Science in Computer Science','MSCS','master',30,2,4,3.00,'Advanced graduate program in computer science with research focus.',NULL,'active','2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `degree_programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `head_teacher_id` bigint unsigned DEFAULT NULL,
  `established_year` year DEFAULT NULL,
  `budget` decimal(15,2) DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `departments_code_unique` (`code`),
  KEY `departments_head_teacher_id_foreign` (`head_teacher_id`),
  CONSTRAINT `departments_head_teacher_id_foreign` FOREIGN KEY (`head_teacher_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'Computer Science','CS','Department of Computer Science and Engineering',NULL,2010,NULL,NULL,NULL,NULL,'active','2026-01-18 14:19:56','2026-01-18 14:19:56'),(2,'Business Administration','BA','Department of Business Administration',NULL,2008,NULL,NULL,NULL,NULL,'active','2026-01-18 14:19:56','2026-01-18 14:19:56'),(3,'Engineering','ENG','Department of Engineering',NULL,2005,NULL,NULL,NULL,NULL,'active','2026-01-18 14:19:56','2026-01-18 14:19:56');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollment_audit_logs`
--

DROP TABLE IF EXISTS `enrollment_audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enrollment_audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `enrollment_id` bigint unsigned NOT NULL,
  `action` enum('created','approved','rejected','removed','confirmed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `performed_by` bigint unsigned NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `enrollment_audit_logs_performed_by_foreign` (`performed_by`),
  KEY `enrollment_audit_logs_enrollment_id_index` (`enrollment_id`),
  KEY `enrollment_audit_logs_action_index` (`action`),
  KEY `enrollment_audit_logs_created_at_index` (`created_at`),
  CONSTRAINT `enrollment_audit_logs_enrollment_id_foreign` FOREIGN KEY (`enrollment_id`) REFERENCES `enrollments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `enrollment_audit_logs_performed_by_foreign` FOREIGN KEY (`performed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollment_audit_logs`
--

LOCK TABLES `enrollment_audit_logs` WRITE;
/*!40000 ALTER TABLE `enrollment_audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `enrollment_audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollment_confirmation_courses`
--

DROP TABLE IF EXISTS `enrollment_confirmation_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enrollment_confirmation_courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `enrollment_confirmation_id` bigint unsigned NOT NULL,
  `course_id` bigint unsigned NOT NULL,
  `course_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `course_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `units` int NOT NULL,
  `prerequisites_met` tinyint(1) NOT NULL DEFAULT '1',
  `has_schedule_conflict` tinyint(1) NOT NULL DEFAULT '0',
  `conflict_details` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ec_courses_ec_id_idx` (`enrollment_confirmation_id`),
  KEY `enrollment_confirmation_courses_course_id_index` (`course_id`),
  CONSTRAINT `ec_courses_ec_id_fk` FOREIGN KEY (`enrollment_confirmation_id`) REFERENCES `enrollment_confirmations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `enrollment_confirmation_courses_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollment_confirmation_courses`
--

LOCK TABLES `enrollment_confirmation_courses` WRITE;
/*!40000 ALTER TABLE `enrollment_confirmation_courses` DISABLE KEYS */;
/*!40000 ALTER TABLE `enrollment_confirmation_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollment_confirmations`
--

DROP TABLE IF EXISTS `enrollment_confirmations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enrollment_confirmations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `semester_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_year` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_courses` int NOT NULL DEFAULT '0',
  `total_units` int NOT NULL DEFAULT '0',
  `prerequisites_satisfied` tinyint(1) NOT NULL DEFAULT '0',
  `schedule_conflicts_resolved` tinyint(1) NOT NULL DEFAULT '0',
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `timetable_understood` tinyint(1) NOT NULL DEFAULT '0',
  `attendance_policy_agreed` tinyint(1) NOT NULL DEFAULT '0',
  `academic_calendar_checked` tinyint(1) NOT NULL DEFAULT '0',
  `confirmation_date` date DEFAULT NULL,
  `confirmation_email_sent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `admin_override` tinyint(1) NOT NULL DEFAULT '0',
  `override_by` bigint unsigned DEFAULT NULL,
  `override_reason` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `enrollment_confirmations_student_id_semester_code_index` (`student_id`,`semester_code`),
  KEY `enrollment_confirmations_confirmed_index` (`confirmed`),
  KEY `enrollment_confirmations_override_by_foreign` (`override_by`),
  KEY `enrollment_confirmations_admin_override_index` (`admin_override`),
  CONSTRAINT `enrollment_confirmations_override_by_foreign` FOREIGN KEY (`override_by`) REFERENCES `users` (`id`),
  CONSTRAINT `enrollment_confirmations_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollment_confirmations`
--

LOCK TABLES `enrollment_confirmations` WRITE;
/*!40000 ALTER TABLE `enrollment_confirmations` DISABLE KEYS */;
/*!40000 ALTER TABLE `enrollment_confirmations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollments`
--

DROP TABLE IF EXISTS `enrollments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enrollments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `course_id` bigint unsigned NOT NULL,
  `enrollment_date` date NOT NULL,
  `status` enum('enrolled','completed','dropped','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enrolled',
  `grade` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credits_earned` decimal(3,1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `requires_approval` tinyint(1) NOT NULL DEFAULT '0',
  `approved_by` bigint unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `enrollments_student_id_course_id_unique` (`student_id`,`course_id`),
  KEY `enrollments_course_id_foreign` (`course_id`),
  KEY `enrollments_approved_by_foreign` (`approved_by`),
  KEY `enrollments_requires_approval_index` (`requires_approval`),
  KEY `enrollments_approved_at_index` (`approved_at`),
  CONSTRAINT `enrollments_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `enrollments_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `enrollments_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollments`
--

LOCK TABLES `enrollments` WRITE;
/*!40000 ALTER TABLE `enrollments` DISABLE KEYS */;
/*!40000 ALTER TABLE `enrollments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
INSERT INTO `failed_jobs` VALUES (1,'4fb0c6e2-8e5f-4af3-a2c2-bbe040d59fe6','database','default','{\"uuid\":\"4fb0c6e2-8e5f-4af3-a2c2-bbe040d59fe6\",\"displayName\":\"App\\\\Mail\\\\WelcomeMail\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:20:\\\"App\\\\Mail\\\\WelcomeMail\\\":4:{s:4:\\\"user\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:17:\\\"temporaryPassword\\\";s:7:\\\"Test123\\\";s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:24:\\\"admin@academic-nexus.com\\\";}}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:3:\\\"job\\\";N;}\"}}','Symfony\\Component\\Mailer\\Exception\\UnexpectedResponseException: Expected response code \"250\" but got code \"530\", with message \"530 5.7.1 Authentication required\". in /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php:331\nStack trace:\n#0 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(187): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->assertResponseCode(\'530 5.7.1 Authe...\', Array)\n#1 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/symfony/mailer/Transport/Smtp/EsmtpTransport.php(150): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->executeCommand(\'MAIL FROM:<nore...\', Array)\n#2 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(252): Symfony\\Component\\Mailer\\Transport\\Smtp\\EsmtpTransport->executeCommand(\'MAIL FROM:<nore...\', Array)\n#3 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(204): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->doMailFromCommand(\'noreply@academi...\', false)\n#4 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/symfony/mailer/Transport/AbstractTransport.php(69): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->doSend(Object(Symfony\\Component\\Mailer\\SentMessage))\n#5 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(138): Symfony\\Component\\Mailer\\Transport\\AbstractTransport->send(Object(Symfony\\Component\\Mime\\Email), Object(Symfony\\Component\\Mailer\\DelayedEnvelope))\n#6 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(585): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->send(Object(Symfony\\Component\\Mime\\Email), Object(Symfony\\Component\\Mailer\\DelayedEnvelope))\n#7 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(332): Illuminate\\Mail\\Mailer->sendSymfonyMessage(Object(Symfony\\Component\\Mime\\Email))\n#8 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(207): Illuminate\\Mail\\Mailer->send(Object(Closure), Array, Object(Closure))\n#9 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->{closure:Illuminate\\Mail\\Mailable::send():200}()\n#10 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(200): Illuminate\\Mail\\Mailable->withLocale(NULL, Object(Closure))\n#11 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(83): Illuminate\\Mail\\Mailable->send(Object(Illuminate\\Mail\\MailManager))\n#12 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle(Object(Illuminate\\Mail\\MailManager))\n#13 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#14 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#15 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#16 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#17 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(126): Illuminate\\Container\\Container->call(Array)\n#18 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Bus\\Dispatcher->{closure:Illuminate\\Bus\\Dispatcher::dispatchNow():123}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#19 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():168}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#20 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(130): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#21 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(126): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(Illuminate\\Mail\\SendQueuedMailable), false)\n#22 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Queue\\CallQueuedHandler->{closure:Illuminate\\Queue\\CallQueuedHandler::dispatchThroughMiddleware():121}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#23 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->{closure:Illuminate\\Pipeline\\Pipeline::prepareDestination():168}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#24 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(121): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#25 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(69): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Mail\\SendQueuedMailable))\n#26 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#27 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(442): Illuminate\\Queue\\Jobs\\Job->fire()\n#28 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(392): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#29 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(335): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#30 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(149): Illuminate\\Queue\\Worker->runNextJob(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#31 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(132): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#32 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#33 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#34 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#35 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#36 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#37 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Console/Command.php(213): Illuminate\\Container\\Container->call(Array)\n#38 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/symfony/console/Command/Command.php(318): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#39 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Console/Command.php(182): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#40 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/symfony/console/Application.php(1073): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#41 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#42 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#43 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#44 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#45 /Applications/MAMP/htdocs/academic-nexus-portal/laravel-backend/artisan(11): Illuminate\\Foundation\\Application->handleCommand(Object(Symfony\\Component\\Console\\Input\\ArgvInput))\n#46 {main}','2026-01-19 18:52:22');
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fee_structures`
--

DROP TABLE IF EXISTS `fee_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fee_structures` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `program` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `due_date` date NOT NULL,
  `fee_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'tuition',
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fee_structures_program_semester_index` (`program`,`semester`),
  KEY `fee_structures_due_date_index` (`due_date`),
  KEY `fee_structures_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fee_structures`
--

LOCK TABLES `fee_structures` WRITE;
/*!40000 ALTER TABLE `fee_structures` DISABLE KEYS */;
INSERT INTO `fee_structures` VALUES (1,'Computer Science',1,2500.00,'2025-01-15','tuition','Semester 1 tuition fees for Computer Science program','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,'Computer Science',1,300.00,'2025-01-15','library','Library fees for Computer Science students','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(3,'Computer Science',1,500.00,'2025-01-15','lab','Computer lab fees for practical sessions','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(4,'Computer Science',2,2500.00,'2025-06-15','tuition','Semester 2 tuition fees for Computer Science program','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(5,'Computer Science',2,300.00,'2025-06-15','library','Library fees for Computer Science students','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(6,'Computer Science',2,500.00,'2025-06-15','lab','Computer lab fees for practical sessions','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(7,'Business Administration',1,2200.00,'2025-01-15','tuition','Semester 1 tuition fees for Business Administration program','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(8,'Business Administration',1,250.00,'2025-01-15','library','Library fees for Business Administration students','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(9,'Business Administration',1,200.00,'2025-01-15','activity','Student activity and events fee','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(10,'Business Administration',2,2200.00,'2025-06-15','tuition','Semester 2 tuition fees for Business Administration program','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(11,'Engineering',1,2800.00,'2025-01-15','tuition','Semester 1 tuition fees for Engineering program','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(12,'Engineering',1,600.00,'2025-01-15','lab','Engineering lab fees for practical work','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(13,'Engineering',1,400.00,'2025-01-15','workshop','Workshop and equipment usage fees','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(14,'Computer Science',1,150.00,'2024-12-01','late_fee','Late payment penalty fee','active','2026-01-18 14:19:58','2026-01-18 14:19:58'),(15,'Business Administration',1,100.00,'2024-11-30','exam','Examination fees','active','2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `fee_structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback_attachments`
--

DROP TABLE IF EXISTS `feedback_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback_attachments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `feedback_id` bigint unsigned NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int NOT NULL,
  `uploaded_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `feedback_attachments_feedback_id_index` (`feedback_id`),
  CONSTRAINT `feedback_attachments_feedback_id_foreign` FOREIGN KEY (`feedback_id`) REFERENCES `student_feedback` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback_attachments`
--

LOCK TABLES `feedback_attachments` WRITE;
/*!40000 ALTER TABLE `feedback_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback_responses`
--

DROP TABLE IF EXISTS `feedback_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback_responses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `feedback_id` bigint unsigned NOT NULL,
  `responder_id` bigint unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `response_date` date NOT NULL,
  `is_internal_note` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `feedback_responses_feedback_id_index` (`feedback_id`),
  KEY `feedback_responses_responder_id_index` (`responder_id`),
  CONSTRAINT `feedback_responses_feedback_id_foreign` FOREIGN KEY (`feedback_id`) REFERENCES `student_feedback` (`id`) ON DELETE CASCADE,
  CONSTRAINT `feedback_responses_responder_id_foreign` FOREIGN KEY (`responder_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback_responses`
--

LOCK TABLES `feedback_responses` WRITE;
/*!40000 ALTER TABLE `feedback_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fees`
--

DROP TABLE IF EXISTS `fees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fees` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `fee_type` enum('tuition','library','laboratory','exam','late','hostel','transport','miscellaneous') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `due_date` date NOT NULL,
  `paid_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `paid_date` date DEFAULT NULL,
  `payment_method` enum('cash','card','bank_transfer','online','cheque') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','paid','overdue','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `late_fee` decimal(10,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fees_student_id_foreign` (`student_id`),
  CONSTRAINT `fees_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fees`
--

LOCK TABLES `fees` WRITE;
/*!40000 ALTER TABLE `fees` DISABLE KEYS */;
/*!40000 ALTER TABLE `fees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `final_exams`
--

DROP TABLE IF EXISTS `final_exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `final_exams` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `course_id` bigint unsigned NOT NULL,
  `semester_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` decimal(5,2) NOT NULL,
  `max_score` decimal(5,2) NOT NULL DEFAULT '70.00',
  `exam_date` date DEFAULT NULL,
  `exam_venue` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','taken','absent','deferred') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `locked_at` timestamp NULL DEFAULT NULL,
  `submitted_for_moderation_at` timestamp NULL DEFAULT NULL,
  `moderation_status` enum('draft','submitted','moderated','approved','published') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `moderated_by` bigint unsigned DEFAULT NULL,
  `moderated_at` timestamp NULL DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `moderation_notes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `final_exams_course_id_foreign` (`course_id`),
  KEY `final_exams_student_id_course_id_semester_code_index` (`student_id`,`course_id`,`semester_code`),
  KEY `final_exams_status_index` (`status`),
  KEY `final_exams_moderated_by_foreign` (`moderated_by`),
  KEY `final_exams_moderation_status_index` (`moderation_status`),
  KEY `final_exams_published_at_index` (`published_at`),
  CONSTRAINT `final_exams_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `final_exams_moderated_by_foreign` FOREIGN KEY (`moderated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `final_exams_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `final_exams`
--

LOCK TABLES `final_exams` WRITE;
/*!40000 ALTER TABLE `final_exams` DISABLE KEYS */;
/*!40000 ALTER TABLE `final_exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_points`
--

DROP TABLE IF EXISTS `grade_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grade_points` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `letter_grade` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `min_percentage` decimal(5,2) NOT NULL,
  `max_percentage` decimal(5,2) NOT NULL,
  `grade_point` decimal(3,2) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_passing` tinyint(1) NOT NULL DEFAULT '1',
  `order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `grade_points_letter_grade_unique` (`letter_grade`),
  KEY `grade_points_letter_grade_index` (`letter_grade`),
  KEY `grade_points_grade_point_index` (`grade_point`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grade_points`
--

LOCK TABLES `grade_points` WRITE;
/*!40000 ALTER TABLE `grade_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_uploads`
--

DROP TABLE IF EXISTS `grade_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grade_uploads` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned NOT NULL,
  `teacher_id` bigint unsigned NOT NULL,
  `grade_type` enum('assignment','test','exam','quiz') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'assignment',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `upload_metadata` json DEFAULT NULL,
  `status` enum('pending','processing','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `processing_results` json DEFAULT NULL,
  `total_records` int DEFAULT NULL,
  `successful_records` int DEFAULT NULL,
  `failed_records` int DEFAULT NULL,
  `error_messages` text COLLATE utf8mb4_unicode_ci,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `grade_uploads_teacher_id_foreign` (`teacher_id`),
  KEY `grade_uploads_course_id_teacher_id_index` (`course_id`,`teacher_id`),
  KEY `grade_uploads_grade_type_index` (`grade_type`),
  KEY `grade_uploads_status_index` (`status`),
  CONSTRAINT `grade_uploads_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `grade_uploads_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grade_uploads`
--

LOCK TABLES `grade_uploads` WRITE;
/*!40000 ALTER TABLE `grade_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grades`
--

DROP TABLE IF EXISTS `grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grades` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `course_id` bigint unsigned NOT NULL,
  `assessment_type` enum('assignment','quiz','midterm','final','project','presentation') COLLATE utf8mb4_unicode_ci NOT NULL,
  `assessment_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_marks` decimal(6,2) NOT NULL,
  `obtained_marks` decimal(6,2) NOT NULL,
  `grade_letter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grade_point` decimal(3,2) DEFAULT NULL,
  `assessment_date` date NOT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `grades_student_id_foreign` (`student_id`),
  KEY `grades_course_id_foreign` (`course_id`),
  CONSTRAINT `grades_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `grades_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grades`
--

LOCK TABLES `grades` WRITE;
/*!40000 ALTER TABLE `grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostels`
--

DROP TABLE IF EXISTS `hostels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hostels` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` enum('male','female','mixed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_rooms` int unsigned NOT NULL,
  `capacity` int unsigned NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hostels_code_unique` (`code`),
  KEY `hostels_code_index` (`code`),
  KEY `hostels_gender_index` (`gender`),
  KEY `hostels_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostels`
--

LOCK TABLES `hostels` WRITE;
/*!40000 ALTER TABLE `hostels` DISABLE KEYS */;
INSERT INTO `hostels` VALUES (1,'Unity Hall','UH','male',120,480,'Main male hostel with modern facilities and study rooms','North Campus',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,'Excellence Hall','EH','female',100,400,'Premier female hostel with attached bathrooms and common rooms','North Campus',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(3,'Victory Hall','VH','male',80,320,'Affordable male hostel near the library','South Campus',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(4,'Grace Hall','GH','female',90,360,'Modern female hostel with WiFi and laundry facilities','South Campus',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(5,'Legacy Hall','LH','male',60,240,'Graduate student male hostel with single rooms','East Campus',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(6,'Wisdom Hall','WH','female',70,280,'Graduate student female hostel near research facilities','East Campus',1,'2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `hostels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insurance_config`
--

DROP TABLE IF EXISTS `insurance_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insurance_config` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `requirement_level` enum('mandatory','optional','disabled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'optional',
  `blocks_registration` tinyint(1) NOT NULL DEFAULT '0',
  `academic_year` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `insurance_config_updated_by_foreign` (`updated_by`),
  KEY `insurance_config_academic_year_index` (`academic_year`),
  CONSTRAINT `insurance_config_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance_config`
--

LOCK TABLES `insurance_config` WRITE;
/*!40000 ALTER TABLE `insurance_config` DISABLE KEYS */;
INSERT INTO `insurance_config` VALUES (1,'mandatory',1,'2026/2027',1,'2026-01-18 14:19:59','2026-01-18 14:19:59');
/*!40000 ALTER TABLE `insurance_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_id` bigint unsigned NOT NULL,
  `fee_structure_id` bigint unsigned NOT NULL,
  `amount_due` decimal(10,2) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(10,2) NOT NULL,
  `due_date` date NOT NULL,
  `issued_date` date NOT NULL,
  `status` enum('pending','partial','paid','overdue','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `description` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_invoice_number_unique` (`invoice_number`),
  KEY `invoices_fee_structure_id_foreign` (`fee_structure_id`),
  KEY `invoices_student_id_status_index` (`student_id`,`status`),
  KEY `invoices_due_date_index` (`due_date`),
  KEY `invoices_status_index` (`status`),
  KEY `invoices_invoice_number_index` (`invoice_number`),
  CONSTRAINT `invoices_fee_structure_id_foreign` FOREIGN KEY (`fee_structure_id`) REFERENCES `fee_structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoices_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (1,'INV-202601-0001',1,1,2500.00,2500.00,0.00,'2025-01-15','2026-01-05','paid','Semester 1 tuition fees for Computer Science program',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,'INV-202601-0002',1,2,300.00,300.00,0.00,'2025-01-15','2025-12-26','paid','Library fees for Computer Science students',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(3,'INV-202601-0003',1,3,500.00,500.00,0.00,'2025-01-15','2025-12-26','paid','Computer lab fees for practical sessions',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(4,'INV-202601-0004',1,4,2500.00,2500.00,0.00,'2025-06-15','2025-12-26','paid','Semester 2 tuition fees for Computer Science program',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(5,'INV-202601-0005',1,5,300.00,300.00,0.00,'2025-06-15','2025-12-23','paid','Library fees for Computer Science students',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(6,'INV-202601-0006',1,6,500.00,250.00,250.00,'2025-06-15','2025-12-24','partial','Computer lab fees for practical sessions',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(7,'INV-202601-0007',1,14,150.00,75.00,75.00,'2024-12-01','2026-01-07','partial','Late payment penalty fee',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(8,'INV-202601-0008',2,7,2200.00,1100.00,1100.00,'2025-01-15','2026-01-09','partial','Semester 1 tuition fees for Business Administration program',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(9,'INV-202601-0009',2,8,250.00,0.00,250.00,'2025-12-31','2025-12-19','pending','Library fees for Business Administration students',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(10,'INV-202601-0010',2,9,200.00,0.00,200.00,'2025-12-23','2025-12-22','pending','Student activity and events fee',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(11,'INV-202601-0011',2,10,2200.00,0.00,2200.00,'2025-12-24','2025-12-19','pending','Semester 2 tuition fees for Business Administration program',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(12,'INV-202601-0012',2,15,100.00,0.00,100.00,'2026-01-01','2026-01-02','pending','Examination fees',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_attempts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2024_01_01_000000_create_users_table',1),(2,'2024_01_02_000000_create_departments_table',1),(3,'2024_01_03_000000_create_students_table',1),(4,'2024_01_04_000000_create_teachers_table',1),(5,'2024_01_05_000000_create_courses_table',1),(6,'2024_01_06_000000_create_enrollments_table',1),(7,'2024_01_07_000000_create_attendances_table',1),(8,'2024_01_08_000000_create_grades_table',1),(9,'2024_01_09_000000_create_announcements_table',1),(10,'2024_01_10_000000_create_fees_table',1),(11,'2025_11_19_082153_create_personal_access_tokens_table',1),(12,'2025_11_22_070257_create_password_reset_tokens_table',1),(13,'2025_11_25_124051_add_student_fields_to_users_table',1),(14,'2025_11_30_203310_create_assignments_table',1),(15,'2025_12_05_230126_create_assignment_grades_table',1),(16,'2025_12_16_204734_create_fee_structures_table',1),(17,'2025_12_17_073558_create_invoices_table',1),(18,'2025_12_17_073607_create_payments_table',1),(19,'2025_12_17_191335_create_assignment_submissions_table',1),(20,'2025_12_17_191411_create_grade_uploads_table',1),(21,'2026_01_09_135657_create_grade_points_table',1),(22,'2026_01_09_144716_create_timetables_table',1),(23,'2026_01_09_145130_create_academic_calendars_table',1),(24,'2026_01_09_145152_create_course_prerequisites_table',1),(25,'2026_01_09_145156_create_course_waitlists_table',1),(26,'2026_01_09_145159_create_degree_programs_table',1),(27,'2026_01_09_145202_create_program_requirements_table',1),(28,'2026_01_09_145205_add_weighted_grading_to_courses_table',1),(29,'2026_01_09_211341_add_degree_program_to_students_table',1),(30,'2026_01_15_073705_create_registrations_table',1),(31,'2026_01_15_073741_create_student_insurance_table',1),(32,'2026_01_15_073834_create_continuous_assessments_table',1),(33,'2026_01_15_073834_create_enrollment_confirmations_table',1),(34,'2026_01_15_073835_create_enrollment_confirmation_courses_table',1),(35,'2026_01_15_073835_create_final_exams_table',1),(36,'2026_01_15_073835_create_semester_summaries_table',1),(37,'2026_01_15_073835_create_student_accommodations_table',1),(38,'2026_01_15_073836_create_accommodation_amenities_table',1),(39,'2026_01_15_073836_create_accommodation_fees_table',1),(40,'2026_01_15_073836_create_accommodation_roommates_table',1),(41,'2026_01_15_073836_create_student_feedback_table',1),(42,'2026_01_15_073837_create_feedback_attachments_table',1),(43,'2026_01_15_073837_create_feedback_responses_table',1),(44,'2026_01_15_090750_create_hostels_table',1),(45,'2026_01_15_090803_create_rooms_table',1),(46,'2026_01_15_090804_create_enrollment_audit_logs_table',1),(47,'2026_01_15_090804_create_insurance_config_table',1),(48,'2026_01_15_090804_create_notifications_table',1),(49,'2026_01_15_090804_create_registration_audit_logs_table',1),(50,'2026_01_15_090815_add_admin_fields_to_registrations',1),(51,'2026_01_15_090815_add_admin_fields_to_student_insurance',1),(52,'2026_01_15_090815_add_lecturer_admin_fields_to_continuous_assessments',1),(53,'2026_01_15_090815_add_lecturer_admin_fields_to_final_exams',1),(54,'2026_01_15_090837_add_admin_fields_to_enrollments',1),(55,'2026_01_15_090838_add_admin_fields_to_enrollment_confirmations',1),(56,'2026_01_15_090838_add_admin_fields_to_student_accommodations',1),(57,'2026_01_15_090838_add_admin_fields_to_student_feedback',1),(58,'2026_01_18_214233_create_audit_logs_table',2),(59,'2026_01_18_220509_create_login_attempts_table',2),(60,'2026_01_19_211341_create_notification_preferences_table',3),(61,'2026_01_19_214754_create_jobs_table',4),(62,'2026_01_19_215029_create_failed_jobs_table',5),(63,'2026_01_20_164832_create_cache_table',6);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_preferences`
--

DROP TABLE IF EXISTS `notification_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_preferences` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `email_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `sms_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `push_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `email_grades` tinyint(1) NOT NULL DEFAULT '1',
  `email_payments` tinyint(1) NOT NULL DEFAULT '1',
  `email_announcements` tinyint(1) NOT NULL DEFAULT '1',
  `email_attendance` tinyint(1) NOT NULL DEFAULT '1',
  `email_timetable` tinyint(1) NOT NULL DEFAULT '1',
  `sms_grades` tinyint(1) NOT NULL DEFAULT '0',
  `sms_payments` tinyint(1) NOT NULL DEFAULT '0',
  `sms_urgent` tinyint(1) NOT NULL DEFAULT '1',
  `app_all` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_preferences_user_id_unique` (`user_id`),
  CONSTRAINT `notification_preferences_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_preferences`
--

LOCK TABLES `notification_preferences` WRITE;
/*!40000 ALTER TABLE `notification_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_unread` (`user_id`,`read_at`),
  KEY `notifications_type_index` (`type`),
  KEY `notifications_created_at_index` (`created_at`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `password_reset_tokens_token_unique` (`token`),
  KEY `password_reset_tokens_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payment_reference` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_id` bigint unsigned NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` enum('cash','bank_transfer','credit_card','debit_card','cheque','online') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_notes` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','completed','failed','refunded') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'completed',
  `processed_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_payment_reference_unique` (`payment_reference`),
  KEY `payments_processed_by_foreign` (`processed_by`),
  KEY `payments_invoice_id_status_index` (`invoice_id`,`status`),
  KEY `payments_payment_date_index` (`payment_date`),
  KEY `payments_payment_reference_index` (`payment_reference`),
  KEY `payments_transaction_id_index` (`transaction_id`),
  CONSTRAINT `payments_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_processed_by_foreign` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,'PAY-202601-0001',6,250.00,'2026-01-11','bank_transfer','TXN-696D163ED128A','Partial payment for Computer lab fees for practical sessions','completed',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,'PAY-202601-0002',7,45.00,'2026-01-13','cheque','TXN-696D163ED12D1','First installment for Late payment penalty fee','completed',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(3,'PAY-202601-0003',7,30.00,'2026-01-15','bank_transfer','TXN-696D163ED12EF','Second installment for Late payment penalty fee','completed',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(4,'PAY-202601-0004',8,660.00,'2026-01-08','credit_card','TXN-696D163ED1317','First installment for Semester 1 tuition fees for Business Administration program','completed',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(5,'PAY-202601-0005',8,440.00,'2026-01-16','credit_card','TXN-696D163ED1331','Second installment for Semester 1 tuition fees for Business Administration program','completed',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(6,'PAY-202601-0006',1,2500.00,'2026-01-05','bank_transfer','TXN-696D163ED1355','Full payment for Semester 1 tuition fees for Computer Science program','completed',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(7,'PAY-202601-0007',2,300.00,'2026-01-09','bank_transfer','TXN-696D163ED1379','Full payment for Library fees for Computer Science students','completed',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(8,'PAY-202601-0008',3,500.00,'2026-01-06','credit_card','TXN-696D163ED139B','Full payment for Computer lab fees for practical sessions','completed',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(9,'PAY-202601-0009',4,2500.00,'2026-01-07','debit_card','TXN-696D163ED13BC','Full payment for Semester 2 tuition fees for Computer Science program','completed',1,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(10,'PAY-202601-0010',5,300.00,'2026-01-10','credit_card','TXN-696D163ED13DE','Full payment for Library fees for Computer Science students','completed',1,'2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (3,'App\\Models\\User',1,'auth_token','6b2c762026d3f98440eb42dceaf17c223b50f59d035e251d250db2bd47f872ab','[\"*\"]','2026-01-18 17:21:52',NULL,'2026-01-18 15:29:33','2026-01-18 17:21:52');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program_requirements`
--

DROP TABLE IF EXISTS `program_requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `program_requirements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `degree_program_id` bigint unsigned NOT NULL,
  `course_id` bigint unsigned NOT NULL,
  `requirement_type` enum('core','major','minor','elective','general_education','capstone') COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester_recommended` int DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '1',
  `credits` int NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `program_requirements_degree_program_id_course_id_unique` (`degree_program_id`,`course_id`),
  KEY `program_requirements_course_id_foreign` (`course_id`),
  KEY `program_requirements_degree_program_id_requirement_type_index` (`degree_program_id`,`requirement_type`),
  CONSTRAINT `program_requirements_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `program_requirements_degree_program_id_foreign` FOREIGN KEY (`degree_program_id`) REFERENCES `degree_programs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program_requirements`
--

LOCK TABLES `program_requirements` WRITE;
/*!40000 ALTER TABLE `program_requirements` DISABLE KEYS */;
INSERT INTO `program_requirements` VALUES (1,1,1,'core',1,1,3,0,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,1,2,'core',1,1,3,1,'2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `program_requirements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registration_audit_logs`
--

DROP TABLE IF EXISTS `registration_audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registration_audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `registration_id` bigint unsigned NOT NULL,
  `action` enum('created','fees_verified','insurance_verified','blocked','unblocked','overridden') COLLATE utf8mb4_unicode_ci NOT NULL,
  `performed_by` bigint unsigned NOT NULL,
  `old_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `registration_audit_logs_performed_by_foreign` (`performed_by`),
  KEY `registration_audit_logs_registration_id_index` (`registration_id`),
  KEY `registration_audit_logs_action_index` (`action`),
  KEY `registration_audit_logs_created_at_index` (`created_at`),
  CONSTRAINT `registration_audit_logs_performed_by_foreign` FOREIGN KEY (`performed_by`) REFERENCES `users` (`id`),
  CONSTRAINT `registration_audit_logs_registration_id_foreign` FOREIGN KEY (`registration_id`) REFERENCES `registrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration_audit_logs`
--

LOCK TABLES `registration_audit_logs` WRITE;
/*!40000 ALTER TABLE `registration_audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `registration_audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registrations`
--

DROP TABLE IF EXISTS `registrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `semester_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_year` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','verified','incomplete') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `total_fees` decimal(10,2) NOT NULL DEFAULT '0.00',
  `amount_paid` decimal(10,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `fees_verified` tinyint(1) NOT NULL DEFAULT '0',
  `insurance_verified` tinyint(1) NOT NULL DEFAULT '0',
  `registration_date` date DEFAULT NULL,
  `verification_date` date DEFAULT NULL,
  `verified_by` bigint unsigned DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `fees_verified_by` bigint unsigned DEFAULT NULL,
  `fees_verified_at` timestamp NULL DEFAULT NULL,
  `registration_blocked` tinyint(1) NOT NULL DEFAULT '0',
  `blocked_by` bigint unsigned DEFAULT NULL,
  `blocked_at` timestamp NULL DEFAULT NULL,
  `block_reason` text COLLATE utf8mb4_unicode_ci,
  `override_by` bigint unsigned DEFAULT NULL,
  `override_at` timestamp NULL DEFAULT NULL,
  `override_reason` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `registrations_verified_by_foreign` (`verified_by`),
  KEY `registrations_student_id_semester_code_index` (`student_id`,`semester_code`),
  KEY `registrations_status_index` (`status`),
  KEY `registrations_academic_year_index` (`academic_year`),
  KEY `registrations_fees_verified_by_foreign` (`fees_verified_by`),
  KEY `registrations_blocked_by_foreign` (`blocked_by`),
  KEY `registrations_override_by_foreign` (`override_by`),
  KEY `registrations_registration_blocked_index` (`registration_blocked`),
  CONSTRAINT `registrations_blocked_by_foreign` FOREIGN KEY (`blocked_by`) REFERENCES `users` (`id`),
  CONSTRAINT `registrations_fees_verified_by_foreign` FOREIGN KEY (`fees_verified_by`) REFERENCES `users` (`id`),
  CONSTRAINT `registrations_override_by_foreign` FOREIGN KEY (`override_by`) REFERENCES `users` (`id`),
  CONSTRAINT `registrations_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `registrations_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registrations`
--

LOCK TABLES `registrations` WRITE;
/*!40000 ALTER TABLE `registrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `registrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rooms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hostel_id` bigint unsigned NOT NULL,
  `room_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `floor` int unsigned NOT NULL,
  `capacity` int unsigned NOT NULL,
  `current_occupancy` int unsigned NOT NULL DEFAULT '0',
  `status` enum('available','occupied','full','maintenance') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'available',
  `amenities` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_room_per_hostel` (`hostel_id`,`room_number`),
  KEY `rooms_hostel_id_index` (`hostel_id`),
  KEY `rooms_status_index` (`status`),
  KEY `rooms_floor_index` (`floor`),
  CONSTRAINT `rooms_hostel_id_foreign` FOREIGN KEY (`hostel_id`) REFERENCES `hostels` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=520 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES (1,1,'UH101',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,1,'UH102',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(3,1,'UH103',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(4,1,'UH104',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(5,1,'UH105',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(6,1,'UH106',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(7,1,'UH107',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(8,1,'UH108',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(9,1,'UH109',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(10,1,'UH110',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(11,1,'UH111',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(12,1,'UH112',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(13,1,'UH113',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(14,1,'UH114',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(15,1,'UH115',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(16,1,'UH116',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(17,1,'UH117',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(18,1,'UH118',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(19,1,'UH119',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(20,1,'UH120',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(21,1,'UH121',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(22,1,'UH122',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(23,1,'UH123',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(24,1,'UH124',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(25,1,'UH125',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(26,1,'UH126',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(27,1,'UH127',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(28,1,'UH128',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(29,1,'UH129',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(30,1,'UH130',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(31,1,'UH131',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(32,1,'UH132',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(33,1,'UH133',1,4,0,'available',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(34,1,'UH134',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(35,1,'UH135',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(36,1,'UH136',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(37,1,'UH137',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(38,1,'UH138',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(39,1,'UH139',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(40,1,'UH140',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(41,1,'UH201',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(42,1,'UH202',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(43,1,'UH203',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(44,1,'UH204',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(45,1,'UH205',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(46,1,'UH206',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(47,1,'UH207',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(48,1,'UH208',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(49,1,'UH209',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(50,1,'UH210',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(51,1,'UH211',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(52,1,'UH212',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(53,1,'UH213',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(54,1,'UH214',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(55,1,'UH215',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(56,1,'UH216',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(57,1,'UH217',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(58,1,'UH218',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(59,1,'UH219',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(60,1,'UH220',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(61,1,'UH221',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(62,1,'UH222',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(63,1,'UH223',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(64,1,'UH224',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(65,1,'UH225',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(66,1,'UH226',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(67,1,'UH227',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(68,1,'UH228',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(69,1,'UH229',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(70,1,'UH230',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(71,1,'UH231',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(72,1,'UH232',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(73,1,'UH233',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(74,1,'UH234',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(75,1,'UH235',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(76,1,'UH236',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(77,1,'UH237',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(78,1,'UH238',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(79,1,'UH239',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(80,1,'UH240',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(81,1,'UH301',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(82,1,'UH302',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(83,1,'UH303',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(84,1,'UH304',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(85,1,'UH305',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(86,1,'UH306',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(87,1,'UH307',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(88,1,'UH308',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(89,1,'UH309',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(90,1,'UH310',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(91,1,'UH311',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(92,1,'UH312',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(93,1,'UH313',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(94,1,'UH314',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(95,1,'UH315',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(96,1,'UH316',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(97,1,'UH317',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(98,1,'UH318',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(99,1,'UH319',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(100,1,'UH320',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(101,1,'UH321',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(102,1,'UH322',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(103,1,'UH323',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(104,1,'UH324',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(105,1,'UH325',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(106,1,'UH326',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(107,1,'UH327',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(108,1,'UH328',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(109,1,'UH329',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(110,1,'UH330',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(111,1,'UH331',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(112,1,'UH332',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(113,1,'UH333',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(114,1,'UH334',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(115,1,'UH335',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(116,1,'UH336',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(117,1,'UH337',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(118,1,'UH338',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(119,1,'UH339',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(120,1,'UH340',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(121,2,'EH101',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(122,2,'EH102',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(123,2,'EH103',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(124,2,'EH104',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(125,2,'EH105',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(126,2,'EH106',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(127,2,'EH107',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(128,2,'EH108',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(129,2,'EH109',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(130,2,'EH110',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(131,2,'EH111',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(132,2,'EH112',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(133,2,'EH113',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(134,2,'EH114',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(135,2,'EH115',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(136,2,'EH116',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(137,2,'EH117',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(138,2,'EH118',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(139,2,'EH119',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(140,2,'EH120',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(141,2,'EH121',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(142,2,'EH122',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(143,2,'EH123',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(144,2,'EH124',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(145,2,'EH125',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(146,2,'EH126',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(147,2,'EH127',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(148,2,'EH128',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(149,2,'EH129',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(150,2,'EH130',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(151,2,'EH131',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(152,2,'EH132',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(153,2,'EH133',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(154,2,'EH201',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(155,2,'EH202',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(156,2,'EH203',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(157,2,'EH204',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(158,2,'EH205',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(159,2,'EH206',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(160,2,'EH207',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(161,2,'EH208',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(162,2,'EH209',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(163,2,'EH210',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(164,2,'EH211',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(165,2,'EH212',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(166,2,'EH213',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(167,2,'EH214',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(168,2,'EH215',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(169,2,'EH216',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(170,2,'EH217',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(171,2,'EH218',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(172,2,'EH219',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(173,2,'EH220',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(174,2,'EH221',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(175,2,'EH222',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(176,2,'EH223',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(177,2,'EH224',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(178,2,'EH225',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(179,2,'EH226',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(180,2,'EH227',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(181,2,'EH228',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(182,2,'EH229',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(183,2,'EH230',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(184,2,'EH231',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(185,2,'EH232',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(186,2,'EH233',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(187,2,'EH301',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(188,2,'EH302',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(189,2,'EH303',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(190,2,'EH304',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(191,2,'EH305',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(192,2,'EH306',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(193,2,'EH307',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(194,2,'EH308',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(195,2,'EH309',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(196,2,'EH310',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(197,2,'EH311',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(198,2,'EH312',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(199,2,'EH313',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(200,2,'EH314',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(201,2,'EH315',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(202,2,'EH316',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(203,2,'EH317',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(204,2,'EH318',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(205,2,'EH319',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(206,2,'EH320',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(207,2,'EH321',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(208,2,'EH322',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(209,2,'EH323',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(210,2,'EH324',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(211,2,'EH325',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(212,2,'EH326',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(213,2,'EH327',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(214,2,'EH328',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(215,2,'EH329',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(216,2,'EH330',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(217,2,'EH331',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(218,2,'EH332',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(219,2,'EH333',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(220,3,'VH101',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(221,3,'VH102',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(222,3,'VH103',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(223,3,'VH104',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(224,3,'VH105',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(225,3,'VH106',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(226,3,'VH107',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(227,3,'VH108',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(228,3,'VH109',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(229,3,'VH110',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(230,3,'VH111',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(231,3,'VH112',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(232,3,'VH113',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(233,3,'VH114',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(234,3,'VH115',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(235,3,'VH116',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(236,3,'VH117',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(237,3,'VH118',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(238,3,'VH119',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(239,3,'VH120',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(240,3,'VH121',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(241,3,'VH122',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(242,3,'VH123',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(243,3,'VH124',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(244,3,'VH125',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(245,3,'VH126',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(246,3,'VH127',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(247,3,'VH201',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(248,3,'VH202',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(249,3,'VH203',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(250,3,'VH204',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(251,3,'VH205',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(252,3,'VH206',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(253,3,'VH207',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(254,3,'VH208',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(255,3,'VH209',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(256,3,'VH210',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(257,3,'VH211',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(258,3,'VH212',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(259,3,'VH213',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(260,3,'VH214',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(261,3,'VH215',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(262,3,'VH216',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(263,3,'VH217',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(264,3,'VH218',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(265,3,'VH219',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(266,3,'VH220',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(267,3,'VH221',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(268,3,'VH222',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(269,3,'VH223',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(270,3,'VH224',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(271,3,'VH225',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(272,3,'VH226',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(273,3,'VH227',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(274,3,'VH301',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(275,3,'VH302',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(276,3,'VH303',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(277,3,'VH304',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(278,3,'VH305',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(279,3,'VH306',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(280,3,'VH307',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(281,3,'VH308',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(282,3,'VH309',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(283,3,'VH310',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(284,3,'VH311',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(285,3,'VH312',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(286,3,'VH313',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(287,3,'VH314',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(288,3,'VH315',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(289,3,'VH316',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(290,3,'VH317',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(291,3,'VH318',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(292,3,'VH319',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(293,3,'VH320',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(294,3,'VH321',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(295,3,'VH322',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(296,3,'VH323',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(297,3,'VH324',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(298,3,'VH325',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(299,3,'VH326',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(300,3,'VH327',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(301,4,'GH101',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(302,4,'GH102',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(303,4,'GH103',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(304,4,'GH104',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(305,4,'GH105',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(306,4,'GH106',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(307,4,'GH107',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(308,4,'GH108',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(309,4,'GH109',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(310,4,'GH110',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(311,4,'GH111',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(312,4,'GH112',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(313,4,'GH113',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(314,4,'GH114',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(315,4,'GH115',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(316,4,'GH116',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(317,4,'GH117',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(318,4,'GH118',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(319,4,'GH119',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(320,4,'GH120',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(321,4,'GH121',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(322,4,'GH122',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(323,4,'GH123',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(324,4,'GH124',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(325,4,'GH125',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(326,4,'GH126',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(327,4,'GH127',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(328,4,'GH128',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(329,4,'GH129',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(330,4,'GH130',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(331,4,'GH201',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(332,4,'GH202',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(333,4,'GH203',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(334,4,'GH204',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(335,4,'GH205',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(336,4,'GH206',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(337,4,'GH207',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(338,4,'GH208',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(339,4,'GH209',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(340,4,'GH210',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(341,4,'GH211',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(342,4,'GH212',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(343,4,'GH213',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(344,4,'GH214',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(345,4,'GH215',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(346,4,'GH216',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(347,4,'GH217',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(348,4,'GH218',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(349,4,'GH219',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(350,4,'GH220',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(351,4,'GH221',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(352,4,'GH222',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(353,4,'GH223',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(354,4,'GH224',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(355,4,'GH225',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(356,4,'GH226',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(357,4,'GH227',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(358,4,'GH228',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(359,4,'GH229',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(360,4,'GH230',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(361,4,'GH301',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(362,4,'GH302',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(363,4,'GH303',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(364,4,'GH304',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(365,4,'GH305',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(366,4,'GH306',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(367,4,'GH307',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(368,4,'GH308',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(369,4,'GH309',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(370,4,'GH310',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(371,4,'GH311',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(372,4,'GH312',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(373,4,'GH313',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(374,4,'GH314',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(375,4,'GH315',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(376,4,'GH316',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(377,4,'GH317',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(378,4,'GH318',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(379,4,'GH319',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(380,4,'GH320',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(381,4,'GH321',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(382,4,'GH322',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(383,4,'GH323',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(384,4,'GH324',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(385,4,'GH325',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(386,4,'GH326',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(387,4,'GH327',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(388,4,'GH328',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(389,4,'GH329',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(390,4,'GH330',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(391,5,'LH101',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(392,5,'LH102',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(393,5,'LH103',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(394,5,'LH104',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(395,5,'LH105',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(396,5,'LH106',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(397,5,'LH107',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(398,5,'LH108',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(399,5,'LH109',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(400,5,'LH110',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(401,5,'LH111',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(402,5,'LH112',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(403,5,'LH113',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(404,5,'LH114',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(405,5,'LH115',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(406,5,'LH116',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(407,5,'LH117',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(408,5,'LH118',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(409,5,'LH119',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(410,5,'LH120',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(411,5,'LH201',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(412,5,'LH202',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(413,5,'LH203',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(414,5,'LH204',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(415,5,'LH205',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(416,5,'LH206',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(417,5,'LH207',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(418,5,'LH208',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(419,5,'LH209',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(420,5,'LH210',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(421,5,'LH211',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(422,5,'LH212',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(423,5,'LH213',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(424,5,'LH214',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(425,5,'LH215',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(426,5,'LH216',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(427,5,'LH217',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(428,5,'LH218',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(429,5,'LH219',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(430,5,'LH220',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(431,5,'LH301',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(432,5,'LH302',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(433,5,'LH303',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(434,5,'LH304',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(435,5,'LH305',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(436,5,'LH306',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(437,5,'LH307',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(438,5,'LH308',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(439,5,'LH309',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(440,5,'LH310',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(441,5,'LH311',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(442,5,'LH312',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(443,5,'LH313',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(444,5,'LH314',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(445,5,'LH315',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(446,5,'LH316',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(447,5,'LH317',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(448,5,'LH318',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(449,5,'LH319',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(450,5,'LH320',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(451,6,'WH101',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(452,6,'WH102',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(453,6,'WH103',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(454,6,'WH104',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(455,6,'WH105',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(456,6,'WH106',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(457,6,'WH107',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(458,6,'WH108',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(459,6,'WH109',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(460,6,'WH110',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(461,6,'WH111',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(462,6,'WH112',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(463,6,'WH113',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(464,6,'WH114',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(465,6,'WH115',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(466,6,'WH116',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(467,6,'WH117',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(468,6,'WH118',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(469,6,'WH119',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(470,6,'WH120',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(471,6,'WH121',1,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(472,6,'WH122',1,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(473,6,'WH123',1,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(474,6,'WH201',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(475,6,'WH202',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(476,6,'WH203',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(477,6,'WH204',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(478,6,'WH205',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(479,6,'WH206',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(480,6,'WH207',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(481,6,'WH208',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(482,6,'WH209',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(483,6,'WH210',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(484,6,'WH211',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(485,6,'WH212',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(486,6,'WH213',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(487,6,'WH214',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(488,6,'WH215',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(489,6,'WH216',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(490,6,'WH217',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(491,6,'WH218',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(492,6,'WH219',2,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(493,6,'WH220',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(494,6,'WH221',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(495,6,'WH222',2,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(496,6,'WH223',2,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(497,6,'WH301',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(498,6,'WH302',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(499,6,'WH303',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(500,6,'WH304',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(501,6,'WH305',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(502,6,'WH306',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(503,6,'WH307',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(504,6,'WH308',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(505,6,'WH309',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(506,6,'WH310',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(507,6,'WH311',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(508,6,'WH312',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(509,6,'WH313',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(510,6,'WH314',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(511,6,'WH315',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(512,6,'WH316',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(513,6,'WH317',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(514,6,'WH318',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(515,6,'WH319',3,1,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(516,6,'WH320',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(517,6,'WH321',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(518,6,'WH322',3,2,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59'),(519,6,'WH323',3,4,0,'available',NULL,'2026-01-18 14:19:59','2026-01-18 14:19:59');
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semester_summaries`
--

DROP TABLE IF EXISTS `semester_summaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `semester_summaries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `semester_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_year` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_courses` int NOT NULL DEFAULT '0',
  `total_units` int NOT NULL DEFAULT '0',
  `semester_gpa` decimal(3,2) NOT NULL DEFAULT '0.00',
  `cumulative_gpa` decimal(3,2) NOT NULL DEFAULT '0.00',
  `total_units_earned` int NOT NULL DEFAULT '0',
  `semester_status` enum('in_progress','completed','probation','suspended') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'in_progress',
  `transcript_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transcript_generated_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `semester_summaries_student_id_semester_code_unique` (`student_id`,`semester_code`),
  KEY `semester_summaries_student_id_semester_code_index` (`student_id`,`semester_code`),
  KEY `semester_summaries_semester_status_index` (`semester_status`),
  CONSTRAINT `semester_summaries_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semester_summaries`
--

LOCK TABLES `semester_summaries` WRITE;
/*!40000 ALTER TABLE `semester_summaries` DISABLE KEYS */;
/*!40000 ALTER TABLE `semester_summaries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_accommodations`
--

DROP TABLE IF EXISTS `student_accommodations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_accommodations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `academic_year` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hostel_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `block` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floor` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `room_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `room_type` enum('single','double','quad') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'quad',
  `bed_number` int DEFAULT NULL,
  `status` enum('allocated','pending','expired','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'allocated',
  `allocation_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `renewal_eligible` tinyint(1) NOT NULL DEFAULT '0',
  `renewal_deadline` date DEFAULT NULL,
  `allocation_letter_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `special_requirements` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `allocated_by` bigint unsigned DEFAULT NULL,
  `allocated_at` timestamp NULL DEFAULT NULL,
  `vacated_by` bigint unsigned DEFAULT NULL,
  `vacated_at` timestamp NULL DEFAULT NULL,
  `room_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_accommodations_student_id_academic_year_index` (`student_id`,`academic_year`),
  KEY `student_accommodations_status_index` (`status`),
  KEY `student_accommodations_hostel_name_room_number_index` (`hostel_name`,`room_number`),
  KEY `student_accommodations_allocated_by_foreign` (`allocated_by`),
  KEY `student_accommodations_vacated_by_foreign` (`vacated_by`),
  KEY `student_accommodations_room_id_index` (`room_id`),
  KEY `student_accommodations_allocated_at_index` (`allocated_at`),
  CONSTRAINT `student_accommodations_allocated_by_foreign` FOREIGN KEY (`allocated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `student_accommodations_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`),
  CONSTRAINT `student_accommodations_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_accommodations_vacated_by_foreign` FOREIGN KEY (`vacated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_accommodations`
--

LOCK TABLES `student_accommodations` WRITE;
/*!40000 ALTER TABLE `student_accommodations` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_accommodations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_feedback`
--

DROP TABLE IF EXISTS `student_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_feedback` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ticket_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `student_id` bigint unsigned NOT NULL,
  `category` enum('academic','accommodation','fees','portal','general','complaint') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('submitted','in_review','in_progress','resolved','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'submitted',
  `submission_date` date NOT NULL,
  `resolved_date` date DEFAULT NULL,
  `assigned_to` bigint unsigned DEFAULT NULL,
  `response_count` int NOT NULL DEFAULT '0',
  `student_viewed_response` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `student_feedback_ticket_number_unique` (`ticket_number`),
  KEY `student_feedback_assigned_to_foreign` (`assigned_to`),
  KEY `student_feedback_ticket_number_index` (`ticket_number`),
  KEY `student_feedback_student_id_status_index` (`student_id`,`status`),
  KEY `student_feedback_category_index` (`category`),
  KEY `student_feedback_priority_index` (`priority`),
  CONSTRAINT `student_feedback_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `student_feedback_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_feedback`
--

LOCK TABLES `student_feedback` WRITE;
/*!40000 ALTER TABLE `student_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_insurance`
--

DROP TABLE IF EXISTS `student_insurance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_insurance` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `semester_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_year` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` enum('nhis','private','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'nhis',
  `policy_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `status` enum('pending','verified','rejected','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `submission_date` date DEFAULT NULL,
  `verification_date` date DEFAULT NULL,
  `verified_by` bigint unsigned DEFAULT NULL,
  `rejection_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_insurance_verified_by_foreign` (`verified_by`),
  KEY `student_insurance_student_id_semester_code_index` (`student_id`,`semester_code`),
  KEY `student_insurance_status_index` (`status`),
  KEY `student_insurance_expiry_date_index` (`expiry_date`),
  CONSTRAINT `student_insurance_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_insurance_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_insurance`
--

LOCK TABLES `student_insurance` WRITE;
/*!40000 ALTER TABLE `student_insurance` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_insurance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `student_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admission_date` date NOT NULL,
  `department_id` bigint unsigned NOT NULL,
  `degree_program_id` bigint unsigned DEFAULT NULL,
  `cgpa` decimal(3,2) NOT NULL DEFAULT '0.00',
  `total_credits_earned` int NOT NULL DEFAULT '0',
  `current_semester` int NOT NULL DEFAULT '1',
  `expected_graduation_date` date DEFAULT NULL,
  `academic_status` enum('active','probation','suspended','graduated','withdrawn','on_leave') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `semester` int NOT NULL DEFAULT '1',
  `section` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `batch` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_contact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blood_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `religion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_gpa` decimal(3,2) DEFAULT NULL,
  `total_credits` int NOT NULL DEFAULT '0',
  `graduation_date` date DEFAULT NULL,
  `status` enum('enrolled','graduated','dropped','suspended') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'enrolled',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `students_student_id_unique` (`student_id`),
  KEY `students_user_id_foreign` (`user_id`),
  KEY `students_department_id_foreign` (`department_id`),
  KEY `students_degree_program_id_foreign` (`degree_program_id`),
  CONSTRAINT `students_degree_program_id_foreign` FOREIGN KEY (`degree_program_id`) REFERENCES `degree_programs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `students_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `students_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,4,'STU001','2022-09-01',1,NULL,0.00,0,1,NULL,'active',3,'A','2022-26','Robert Doe','+1234567891','robert.doe@email.com',NULL,NULL,NULL,NULL,3.85,45,NULL,'enrolled','2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,5,'STU002','2022-09-01',2,NULL,0.00,0,1,NULL,'active',3,'B','2022-26','Michael Smith','+1234567893','michael.smith@email.com',NULL,NULL,NULL,NULL,3.92,48,NULL,'enrolled','2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teachers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `employee_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` bigint unsigned NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specialization` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `joining_date` date NOT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `experience_years` int NOT NULL DEFAULT '0',
  `office_room` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `office_hours` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `research_interests` text COLLATE utf8mb4_unicode_ci,
  `publications` json DEFAULT NULL,
  `status` enum('active','inactive','on_leave') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `teachers_employee_id_unique` (`employee_id`),
  KEY `teachers_user_id_foreign` (`user_id`),
  KEY `teachers_department_id_foreign` (`department_id`),
  CONSTRAINT `teachers_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `teachers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers`
--

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES (1,2,'TCH001',1,'Professor','PhD in Computer Science','Database Systems','2015-01-15',75000.00,10,NULL,NULL,NULL,NULL,'active','2026-01-18 14:19:57','2026-01-18 14:19:57'),(2,3,'TCH002',2,'Associate Professor','MBA, PhD in Business','Marketing Management','2017-08-20',65000.00,8,NULL,NULL,NULL,NULL,'active','2026-01-18 14:19:57','2026-01-18 14:19:57');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetables`
--

DROP TABLE IF EXISTS `timetables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timetables` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned NOT NULL,
  `teacher_id` bigint unsigned NOT NULL,
  `room_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `building` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day_of_week` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `semester` int NOT NULL,
  `academic_year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capacity` int NOT NULL DEFAULT '50',
  `enrolled_count` int NOT NULL DEFAULT '0',
  `status` enum('active','cancelled','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `timetables_course_id_semester_academic_year_index` (`course_id`,`semester`,`academic_year`),
  KEY `timetables_teacher_id_day_of_week_index` (`teacher_id`,`day_of_week`),
  KEY `timetables_day_of_week_start_time_index` (`day_of_week`,`start_time`),
  CONSTRAINT `timetables_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `timetables_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetables`
--

LOCK TABLES `timetables` WRITE;
/*!40000 ALTER TABLE `timetables` DISABLE KEYS */;
INSERT INTO `timetables` VALUES (1,1,1,'102','A','Tuesday','10:00:00','11:30:00',3,'2026',NULL,50,0,'active',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(2,1,1,'102','A','Wednesday','10:00:00','11:30:00',3,'2026',NULL,50,0,'active',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(3,2,2,'201','B','Wednesday','13:00:00','14:30:00',2,'2026',NULL,45,0,'active',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(4,2,2,'201','B','Thursday','13:00:00','14:30:00',2,'2026',NULL,45,0,'active',NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `timetables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','student','teacher','parent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `program` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `year_level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `student_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `enrollment_date` date DEFAULT NULL,
  `current_cgpa` decimal(3,2) DEFAULT NULL,
  `bio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_links` json DEFAULT NULL,
  `student_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teacher_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('male','female','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_student_id_unique` (`student_id`),
  UNIQUE KEY `users_teacher_id_unique` (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'System Administrator','admin@academic-nexus.com',NULL,'$2y$12$8oaa.uCGoKK9dpwirmZcZ.SOGmpJneyHpCbgdyERxlH9tJy7zoKFm','admin',NULL,NULL,'active',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-01-18 14:19:56','2026-01-18 17:45:41'),(2,'Dr. John Smith','john.smith@academic-nexus.com',NULL,'$2y$12$XNhbYaV5/xstO8.CuZJ3Q.ytEtAOrXOx0xUjCeJMAkbOziquUKVaq','teacher',NULL,NULL,'active',NULL,NULL,NULL,NULL,NULL,'TCH001',NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-01-18 14:19:57','2026-01-18 14:19:57'),(3,'Dr. Sarah Johnson','sarah.johnson@academic-nexus.com',NULL,'$2y$12$9iOb/vOUF9r3q1Tm5Og4w.FexOF0yqaXM9JrZNo88hUaLNaoKOIfO','teacher',NULL,NULL,'active',NULL,NULL,NULL,NULL,NULL,'TCH002',NULL,NULL,NULL,NULL,NULL,1,NULL,'2026-01-18 14:19:57','2026-01-18 14:19:57'),(4,'John Doe','john.doe@student.academic-nexus.com',NULL,'$2y$12$Vm/Jr17xJ/IVodqW1FGsHeZZpO5LuTf4Z5aIRKsvJtE4x/IwqkN6C','student',NULL,NULL,'active',NULL,NULL,NULL,NULL,'STU001',NULL,'+1234567890',NULL,'2002-05-15','male',NULL,1,NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58'),(5,'Jane Smith','jane.smith@student.academic-nexus.com',NULL,'$2y$12$b.Snp3ePvhBNaQdwGyeYk.fuFcmAu3kzWz6r5YQfptRONrg16Bn8S','student',NULL,NULL,'active',NULL,NULL,NULL,NULL,'STU002',NULL,'+1234567892',NULL,'2003-03-22','female',NULL,1,NULL,'2026-01-18 14:19:58','2026-01-18 14:19:58');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-21 21:25:44
